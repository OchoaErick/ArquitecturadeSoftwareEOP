import express from "express";
import amqp from "amqplib";
const app = express();
app.use(express.json());
const exchangeName = "notifications";
let channel;
// Conectar a RabbitMQ una vez al iniciar
async function connectRabbit() {
 const connection = await amqp.connect("amqp://rabbitmq"); // nombre del servicio en Docker
 channel = await connection.createChannel();
 await channel.assertExchange(exchangeName, "fanout", { durable: false });
 console.log("Conectado a RabbitMQ y listo para publicar mensajes");
}

connectRabbit().catch(console.error);

// Endpoint para publicar un mensaje
app.post("/publish", async (req, res) => {
 try {
 const message = req.body.message || "Mensaje vacío";
 // Publica el mensaje al exchange 'notifications'
 channel.publish(exchangeName, "", Buffer.from(message));
 console.log(`Mensaje enviado: ${message}`);
 res.json({ ok: true, message });
 } catch (error) {
 console.error("Error al publicar:", error);
 res.status(500).json({ ok: false, error: error.message });
 }
});

app.get("/", (req, res) => {
 res.send("API Publisher funcionando. Usa POST /publish con { message: '...' }");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`API REST escuchando en puerto ${PORT}`));