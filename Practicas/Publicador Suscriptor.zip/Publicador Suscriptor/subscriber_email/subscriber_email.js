const amqp = require('amqplib');
const exchangeName = 'notifications';

async function startEmailSubscriber() {
    // Usaremos rabbitmq
    const connection = await amqp.connect('amqp://rabbitmq');
    const channel = await connection.createChannel();

    await channel.assertExchange(exchangeName, 'fanout', { durable: false });

    const q = await channel.assertQueue('', { exclusive: true });
    console.log(`[EMAIL] Esperando mensajes en la cola: ${q.queue}`);

    channel.bindQueue(q.queue, exchangeName, '');

    channel.consume(q.queue, (msg) => {
        if (msg.content) {
            console.log(`[EMAIL] Enviando correo con mensaje: '${msg.content.toString()}'`);
        }
    }, { noAck: true });
}

startEmailSubscriber().catch(console.error);