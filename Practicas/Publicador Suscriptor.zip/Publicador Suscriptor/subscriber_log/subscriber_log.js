const amqp = require('amqp');
const exchangeName = 'notifications';

async function startLogSubscriber() {
    // Igualmente, usamos 'amqp://rabbitmq' para Docker
    const connection = await amqp.connect('amqp://rabbitmq');
    const channel = await connection.createChannel();

    await channel.assertExchange(exchangeName, 'fanout', { durable: false });

    const q = await channel.assertQueue('', { exclusive: true });
    console.log(`[LOG] Escuchando mensajes en la cola: ${q.queue}`);

    channel.bindQueue(q.queue, exchangeName, '');

    channel.consume(q.queue, (msg) => {
        if (msg.content) {
            console.log(`[LOG] Registrando mensaje: '${msg.content.toString()}'`);
        }
    }, { noAck: true });
}

startLogSubscriber().catch(console.error);